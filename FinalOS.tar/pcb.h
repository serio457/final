/*
Adriaan EngelBrecht & Kellen Casey
CPUsched
CS 3074
pcb.h
*/

#ifndef PCB_H
#define PCB_H

// A structure to hold data of processes in a linked list
typedef struct
{
  char* name;
  int arrival;
  int burst;
  int priority;
  int runTime;
  int waitTime;
}pcb;

typedef pcb* cpu_t;

pcb* readFile(char* fileName, int* procCount);

#endif
