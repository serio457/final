#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include "CPUsched.h"
#include "queue.h"


int main (void)
{
    printf ("In main\n");
    BOOL arrival = TRUE;
    BOOL burst = TRUE;
    BOOL priority = TRUE;
    int simulationCount = 10;
    simulate(arrival, burst, priority, simulationCount);
    return 0;
}